"""
RFID Connect Layer - 串口调试工具
基于 PySide6 的串口通信工具，支持日志输出和扩展

文件结构:
    - main.py: 主程序
    - test.ui: Qt Designer UI 文件

运行方式:
    cd ~/code/rfid-item/connect-layer
    source .venv/bin/activate
    python main.py
"""

import sys
import os
import serial
import serial.tools.list_ports
import html
import re
from datetime import datetime
from enum import Enum
from typing import Optional
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QMessageBox, QFileDialog,
    QLabel, QPushButton, QComboBox, QDoubleSpinBox,
    QPlainTextEdit, QLineEdit, QCheckBox, QFrame,
    QTabWidget
)
from PySide6.QtCore import QThread, Signal, QObject, Qt, QFile
from PySide6.QtGui import QFont
from PySide6 import QtUiTools
import logging as lg


# ============================================================
# 常量定义
# ============================================================
# 安全常量
MAX_LOG_HISTORY = 10000  # 最大日志历史条数
MAX_DISPLAY_BYTES = 1048576  # 单次最大显示字节数 (1MB)
MAX_SEND_BYTES = 65536  # 单次最大发送字节数 (64KB)
ALLOWED_LOG_EXTENSIONS = {'.txt', '.log', '.md'}  # 允许的日志导出扩展名

lg.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename="./log/app.log",
    filemode="a"
)

log = lg.getLogger(__name__)
log.setLevel(lg.DEBUG)

# ============================================================
# 日志级别定义
# ============================================================
class LogLevel(Enum):
    """日志级别枚举"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


# ============================================================
# 日志类 - 核心日志输出模块
# ============================================================
class Logger(QObject):
    """
    日志输出类
    
    【如何使用日志输出】
    ================
    1. 在主窗口中访问：self.logger.info("消息")
    
    2. 可用方法:
       - self.logger.debug("调试信息")     # 详细调试信息
       - self.logger.info("普通信息")       # 一般信息
       - self.logger.warning("警告信息")    # 警告
       - self.logger.error("错误信息")      # 错误
       - self.logger.critical("严重错误")   # 严重错误
    
    3. 便捷方法:
       - self.logger.rx(data, hex_mode)    # 接收数据日志
       - self.logger.tx(data, hex_mode)    # 发送数据日志
    
    4. 设置日志级别:
       self.logger.set_level(LogLevel.DEBUG)  # 显示所有日志
       self.logger.set_level(LogLevel.INFO)   # 只显示 INFO 及以上
    
    5. 日志格式:
       [HH:MM:SS.mmm] [LEVEL] 消息内容
    """
    # 日志信号：时间戳、级别、消息
    log_signal = Signal(str, str, str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.log_level = LogLevel.INFO
        self._log_history = []
        self._max_history = MAX_LOG_HISTORY
    
    def set_level(self, level: LogLevel):
        """设置日志级别"""
        self.log_level = level
    
    def set_max_history(self, max_lines: int):
        """设置最大日志历史条数（安全限制）"""
        self._max_history = max(100, min(max_lines, MAX_LOG_HISTORY))
    
    def _get_timestamp(self) -> str:
        """获取当前时间戳"""
        return datetime.now().strftime("%H:%M:%S.%f")[:-3]
    
    def _emit_log(self, level: LogLevel, message: str):
        """内部日志发射方法"""
        level_order = {LogLevel.DEBUG: 0, LogLevel.INFO: 1, LogLevel.WARNING: 2, 
                       LogLevel.ERROR: 3, LogLevel.CRITICAL: 4}
        if level_order[level] >= level_order[self.log_level]:
            timestamp = self._get_timestamp()
            log_entry = f"[{timestamp}] [{level.value}] {message}"
            self._log_history.append(log_entry)
            
            # 安全限制：防止内存溢出
            if len(self._log_history) > self._max_history:
                self._log_history = self._log_history[-self._max_history:]
            
            self.log_signal.emit(timestamp, level.value, message)
    
    def debug(self, message: str):
        """DEBUG 级别日志"""
        self._emit_log(LogLevel.DEBUG, message)
    
    def info(self, message: str):
        """INFO 级别日志"""
        self._emit_log(LogLevel.INFO, message)
    
    def warning(self, message: str):
        """WARNING 级别日志"""
        self._emit_log(LogLevel.WARNING, message)
    
    def error(self, message: str):
        """ERROR 级别日志"""
        self._emit_log(LogLevel.ERROR, message)
    
    def critical(self, message: str):
        """CRITICAL 级别日志"""
        self._emit_log(LogLevel.CRITICAL, message)
    
    def rx(self, data: bytes, hex_mode: bool = False):
        """接收数据日志"""
        # 安全限制：截断过大的数据
        if len(data) > MAX_DISPLAY_BYTES:
            data = data[:MAX_DISPLAY_BYTES]
            self.warning(f"接收数据过大，已截断至 {MAX_DISPLAY_BYTES} 字节")
        
        if hex_mode:
            hex_str = ' '.join(f'{b:02X}' for b in data)
            self.debug(f"<- RX [{len(data)} bytes]: {hex_str}")
        else:
            try:
                text = data.decode('utf-8', errors='replace')
                self.debug(f"<- RX [{len(data)} bytes]: {text}")
            except:
                self.debug(f"<- RX [{len(data)} bytes]: {data}")
    
    def tx(self, data: bytes, hex_mode: bool = False):
        """发送数据日志"""
        if hex_mode:
            hex_str = ' '.join(f'{b:02X}' for b in data)
            self.info(f"-> TX [{len(data)} bytes]: {hex_str}")
        else:
            try:
                text = data.decode('utf-8', errors='replace')
                self.info(f"-> TX [{len(data)} bytes]: {text}")
            except:
                self.info(f"-> TX [{len(data)} bytes]: {data}")
    
    def get_history(self) -> list:
        """获取日志历史"""
        return self._log_history.copy()
    
    def clear_history(self):
        """清空日志历史"""
        self._log_history.clear()


# ============================================================
# 串口工作线程
# ============================================================
class SerialWorker(QObject):
    """串口通信工作线程"""
    
    data_received = Signal(bytes)
    connected = Signal(bool)
    error_occurred = Signal(str)
    
    def __init__(self):
        super().__init__()
        self.serial: Optional[serial.Serial] = None
        self._running = False
        self._read_thread: Optional[QThread] = None
        self._lock = QThread()
    
    def connect(self, port: str, baudrate: int, timeout: float) -> bool:
        """连接串口"""
        try:
            # 安全验证：检查端口名称格式
            if not self._validate_port_name(port):
                self.error_occurred.emit(f"无效的串口端口名称")
                self.connected.emit(False)
                return False
            
            self.serial = serial.Serial(
                port=port,
                baudrate=baudrate,
                timeout=timeout,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE
            )
            self._running = True
            self.connected.emit(True)
            return True
        except serial.SerialException as e:
            # 安全：不泄露详细错误信息
            self.error_occurred.emit(f"串口连接失败：{str(e)}")
            self.connected.emit(False)
            return False
        except Exception as e:
            self.error_occurred.emit(f"未知错误：{str(e)}")
            self.connected.emit(False)
            return False
    
    def _validate_port_name(self, port: str) -> bool:
        """验证串口端口名称格式（安全）"""
        if not port or not isinstance(port, str):
            return False
        # 只允许字母、数字、斜杠、连字符、下划线
        if not re.match(r'^[A-Za-z0-9/_\-\\.]+$', port):
            return False
        # 限制长度
        if len(port) > 256:
            return False
        return True
    
    def disconnect(self):
        """断开串口连接"""
        self._running = False
        if self.serial:
            try:
                if self.serial.is_open:
                    self.serial.close()
            except:
                pass
        self.serial = None
        self.connected.emit(False)
    
    def send(self, data: bytes) -> bool:
        """发送数据"""
        if self.serial and self.serial.is_open:
            try:
                self.serial.write(data)
                self.serial.flush()
                log.debug(f"发送数据成功：{data.hex()}")
                return True
            except Exception as e:
                log.debug(f"发送数据失败：{data.hex()}\n错误：{e}")
                self.error_occurred.emit(f"发送错误：{str(e)}")
                return False
        else:
            log.warning(f"串口未打开时发送数据：{data.hex()}")
        return False
    
    def read_all(self) -> bytes:
        """读取所有可用数据"""
        if self.serial and self.serial.is_open:
            try:
                return self.serial.read_all()
            except serial.SerialException:
                return b''
        return b''
    
    def is_open(self) -> bool:
        """检查串口是否打开"""
        return self.serial is not None and self.serial.is_open
    
    def start_reading(self):
        """开始读取线程"""
        self._read_thread = QThread()
        self.moveToThread(self._read_thread)
        self._read_thread.started.connect(self._read_loop)
        self._read_thread.start()
    
    def _read_loop(self):
        """读取循环"""
        while self._running:
            if self.serial and self.serial.is_open:
                try:
                    data = self.serial.read_all()
                    if data:
                        self.data_received.emit(data)
                except serial.SerialException:
                    pass
                except Exception:
                    pass
            QThread.msleep(50)
    
    def stop_reading(self):
        """停止读取线程"""
        self._running = False
        if self._read_thread:
            self._read_thread.quit()
            self._read_thread.wait()
            self._read_thread = None


# ============================================================
# 主窗口
# ============================================================
class SerialToolWindow(QMainWindow):
    """主窗口类"""
    
    def __init__(self):
        super().__init__()
        log.debug("程序开始运行")
        self.logger = Logger(self)
        self.serial_worker = SerialWorker()
        self.bytes_sent = 0
        self.bytes_received = 0
        self._is_connected = False
        
        # 加载 UI 文件
        self._load_ui()
        
        # 初始化
        self._init_ui_values()
        self._connect_signals()
        
        self.logger.info("应用程序启动")
    
    def _load_ui(self):
        """从 UI 文件加载界面"""
        # 获取 UI 文件路径（相对于脚本位置）
        script_dir = os.path.dirname(os.path.abspath(__file__))
        ui_path = os.path.join(script_dir, "test.ui")
        
        # 安全验证：检查 UI 文件是否存在且路径合法
        if not os.path.exists(ui_path):
            QMessageBox.critical(self, "错误", f"UI 文件不存在：{ui_path}")
            sys.exit(1)
        
        # 安全验证：检查路径是否在预期目录内（防止路径遍历）
        real_path = os.path.realpath(ui_path)
        if not real_path.startswith(script_dir):
            QMessageBox.critical(self, "错误", "UI 文件路径不安全")
            sys.exit(1)
        
        # 加载 UI
        loader = QtUiTools.QUiLoader()
        # loader.setWorkingDirectory(script_dir)
        ui_window = loader.load(QFile(ui_path))
        
        if not ui_window:
            QMessageBox.critical(self, "错误", "无法加载 UI 文件")
            sys.exit(1)
        
        # 将 UI 控件绑定到当前窗口
        self.setCentralWidget(ui_window)
        self.setWindowTitle("test app")
        
        # 绑定所有 UI 控件引用
        self.comboPort = ui_window.findChild(QComboBox, "comboPort")
        self.btnRefresh = ui_window.findChild(QPushButton, "btnRefresh")
        self.comboBaudrate = ui_window.findChild(QComboBox, "comboBaudrate")
        self.spinTimeout = ui_window.findChild(QDoubleSpinBox, "spinTimeout")
        self.btnConnect = ui_window.findChild(QPushButton, "btnConnect")
        self.labelConnectionStatus = ui_window.findChild(QLabel, "labelConnectionStatus")
        
        self.tabData = ui_window.findChild(QTabWidget, "tabData")
        self.checkHexReceive = ui_window.findChild(QCheckBox, "checkHexReceive")
        self.btnClearRx = ui_window.findChild(QPushButton, "btnClearRx")
        self.textReceive = ui_window.findChild(QPlainTextEdit, "textReceive")
        
        self.checkHexSend = ui_window.findChild(QCheckBox, "checkHexSend")
        self.btnClearTx = ui_window.findChild(QPushButton, "btnClearTx")
        self.textSend = ui_window.findChild(QPlainTextEdit, "textSend")
        self.lineEditSend = ui_window.findChild(QLineEdit, "lineEditSend")
        self.btnSend = ui_window.findChild(QPushButton, "btnSend")
        
        self.comboLogLevel = ui_window.findChild(QComboBox, "comboLogLevel")
        self.btnClearLog = ui_window.findChild(QPushButton, "btnClearLog")
        self.btnExportLog = ui_window.findChild(QPushButton, "btnExportLog")
        self.textLog = ui_window.findChild(QPlainTextEdit, "textLog")
        
        self.labelStats = ui_window.findChild(QLabel, "labelStats")
        self.frameStatus = ui_window.findChild(QFrame, "frameStatus")

        self.lineEditServerUrl = ui_window.findChild(QLineEdit, "lineEditServerUrl")
        self.lineEditApiToken = ui_window.findChild(QLineEdit, "lineEditApiToken")
        self.lineEditDeviceSeq = ui_window.findChild(QLineEdit, "lineEditDeviceSeq")
        self.btnServerConnect = ui_window.findChild(QPushButton, "btnServerConnect")

        # 感知层通信组件
        self.get_uid_btn = ui_window.findChild(QPushButton, "get_uid_btn")
        self.read_data_btn = ui_window.findChild(QPushButton, "read_data_btn")
        self.write_data_btn = ui_window.findChild(QPushButton, "write_data_btn")
        self.fetch_sensor_btn = ui_window.findChild(QPushButton, "fetch_sensor_btn")

        self.input_data_text = ui_window.findChild(QPlainTextEdit, "input_data_text")
        self.output_data_text = ui_window.findChild(QPlainTextEdit, "output_data_text")

        # print(
        #     self.get_uid_btn,
        #     self.read_data_btn,
        #     self.write_data_btn,
        #     self.fetch_sensor_btn,
        #     self.input_data_text,
        #     self.output_data_text,
        # sep = "\n")

    def _init_ui_values(self):
        """初始化 UI 值"""
        # 波特率选项
        baudrates = [300, 1200, 2400, 4800, 9600, 14400, 19200, 
                     38400, 57600, 115200, 230400, 460800, 921600]
        self.comboBaudrate.addItems([str(b) for b in baudrates])
        self.comboBaudrate.setCurrentText("9600")
        
        # 日志级别选项
        for level in LogLevel:
            self.comboLogLevel.addItem(level.value, level.value)
        self.comboLogLevel.setCurrentText("DEBUG")
        
        # 刷新串口列表
        self._refresh_ports()

        self.lineEditServerUrl.setText("http://127.0.0.1:4343")
        self.lineEditApiToken.setText("")
        self.lineEditDeviceSeq.setText("DEVICE_TEST")
        


    def _connect_signals(self):
        """连接所有信号"""
        # 日志信号
        self.logger.log_signal.connect(self._append_log)
        
        # 按钮信号
        self.btnRefresh.clicked.connect(self._refresh_ports)
        self.btnConnect.clicked.connect(self._toggle_connection)
        self.btnSend.clicked.connect(self._send_data)
        self.btnClearRx.clicked.connect(self._clear_receive)
        self.btnClearTx.clicked.connect(self._clear_send)
        self.btnClearLog.clicked.connect(self._clear_log)
        self.btnExportLog.clicked.connect(self._export_log)
        
        # 串口数据信号
        self.serial_worker.data_received.connect(self._on_data_received)
        self.serial_worker.connected.connect(self._on_connection_changed)
        self.serial_worker.error_occurred.connect(self._on_error)
        
        # 日志级别切换
        self.comboLogLevel.currentTextChanged.connect(self._on_log_level_changed)
        
        # Enter 键发送
        self.lineEditSend.returnPressed.connect(self._send_data)

        self.btnServerConnect.clicked.connect(self._btnServerConnectHandler)


        # 感知层通信按键
        self.get_uid_btn.clicked.connect(self._get_uid_handler)
        self.read_data_btn.clicked.connect(self._read_data_handler)
        self.write_data_btn.clicked.connect(self._write_data_handler)
        self.fetch_sensor_btn.clicked.connect(self._fetch_sensor_handler)

    def _get_uid_handler(self):
        tmp = b"\xaa\x55\x00"+b"\x00"*20
        con = 0
        for b in tmp:
            con ^= b
        tmp+=con.to_bytes(1, "big")

        self.serial_worker.send(tmp)

    def _read_data_handler(self):

        addr = bytes.fromhex(self.input_data_text.toPlainText().strip())

        tmp = b"\xaa\x55\x01"+addr+b"\x00"*19
        con = 0
        for b in tmp:
            con ^= b
        tmp+=con.to_bytes(1, "big")

        self.serial_worker.send(tmp)

    def _write_data_handler(self):
        content = bytes.fromhex(self.input_data_text.toPlainText().replace(" ", "").replace(",", "").strip())
        tmp = b"\xaa\x55\x02"+content+b"\x00"*3
        con = 0
        for b in tmp:
            con ^= b

        tmp+=con.to_bytes(1, "big")
        self.serial_worker.send(tmp)

    def _fetch_sensor_handler(self):
        tmp = b"\xaa\x55\x03"+b"\x00"*20
        con = 0
        for b in tmp:
            con ^= b
        tmp += con.to_bytes(1, "big")
        self.serial_worker.send(tmp)

    def _btnServerConnectHandler(self):
        self.logger.debug("send server connect handler.")
    
    # ============================================================
    # 日志输出方法
    # ============================================================
    def _append_log(self, timestamp: str, level: str, message: str):
        """追加日志到显示区"""
        # 安全：对消息进行 HTML 转义，防止注入
        safe_message = html.escape(message)
        log_text = f"[{timestamp}] [{level}] {safe_message}\n"
        
        colors = {
            "DEBUG": "#6a9955",
            "INFO": "#569cd6",
            "WARNING": "#dcdcaa",
            "ERROR": "#f48771",
            "CRITICAL": "#c586c0"
        }
        color = colors.get(level, "#c9d1d9")
        
        self.textLog.appendHtml(f'<span style="color: {color}">{log_text}</span>')
        scrollbar = self.textLog.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
        # print("add log success.")
    
    def _clear_log(self):
        """清空日志"""
        self.textLog.clear()
        self.logger.clear_history()
        self.logger.info("日志已清空")
    
    def _export_log(self):
        """导出日志到文件"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "导出日志", "", "Text Files (*.txt);;Log Files (*.log);;All Files (*)"
        )
        if file_path:
            # 安全验证：检查文件扩展名
            _, ext = os.path.splitext(file_path)
            if ext.lower() not in ALLOWED_LOG_EXTENSIONS and ext.lower() != '':
                # 允许无扩展名，但不允许危险扩展名
                dangerous_exts = {'.exe', '.bat', '.cmd', '.sh', '.py', '.js', '.vbs'}
                if ext.lower() in dangerous_exts:
                    self.logger.error(f"不允许的文件扩展名：{ext}")
                    QMessageBox.warning(self, "警告", f"不允许导出为该文件类型：{ext}")
                    return
            
            # 安全验证：检查路径是否在安全目录内
            try:
                real_path = os.path.realpath(file_path)
                home_dir = os.path.expanduser("~")
                # 允许写入用户目录
                if not real_path.startswith(home_dir):
                    self.logger.warning(f"尝试写入非用户目录：{real_path}")
                    reply = QMessageBox.question(
                        self, "警告",
                        f"文件将保存到系统目录:\n{real_path}\n\n是否继续？",
                        QMessageBox.Yes | QMessageBox.No
                    )
                    if reply != QMessageBox.Yes:
                        return
            except Exception as e:
                self.logger.error(f"路径验证失败：{str(e)}")
                QMessageBox.critical(self, "错误", "文件路径验证失败")
                return
            
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write('\n'.join(self.logger.get_history()))
                self.logger.info(f"日志已导出到：{os.path.basename(file_path)}")
                QMessageBox.information(self, "成功", f"日志已导出到:\n{file_path}")
            except PermissionError:
                self.logger.error(f"导出日志失败：权限不足")
                QMessageBox.critical(self, "错误", "保存失败：权限不足")
            except Exception as e:
                self.logger.error(f"导出日志失败：{str(e)}")
                QMessageBox.critical(self, "错误", f"导出失败:\n{str(e)}")
    
    def _on_log_level_changed(self, level: str):
        """日志级别改变"""
        log_level = LogLevel(level)
        self.logger.set_level(log_level)
        self.logger.info(f"日志级别已设置为：{level}")
    
    # ============================================================
    # 串口控制方法
    # ============================================================
    def _refresh_ports(self):
        """刷新串口列表"""
        current = self.comboPort.currentData()
        self.comboPort.clear()
        
        ports = serial.tools.list_ports.comports()
        
        for port in sorted(ports, key=lambda p: p.device):
            # 安全：清理端口描述中的特殊字符
            safe_desc = html.escape(str(port.description))
            display = f"{port.device} - {safe_desc}"
            self.comboPort.addItem(display, port.device)
        
        if self.comboPort.count() == 0:
            self.comboPort.addItem("未找到串口", "")
            self.logger.warning("未找到可用串口")
        else:
            index = self.comboPort.findData(current)
            if index >= 0:
                self.comboPort.setCurrentIndex(index)
            self.logger.info(f"找到 {self.comboPort.count()} 个串口")
    
    def _toggle_connection(self):
        """切换串口连接状态"""
        if self._is_connected:
            self._disconnect()
        else:
            self._connect()
    
    def _connect(self):
        """连接串口"""
        port = self.comboPort.currentData()
        if not port:
            QMessageBox.warning(self, "警告", "请选择有效的串口端口")
            return
        
        # 检查是否选择了有效端口
        if self.comboPort.currentText() == "未找到串口":
            QMessageBox.warning(self, "警告", "未找到可用串口，请检查设备连接")
            return
        
        baudrate = int(self.comboBaudrate.currentText())
        timeout = self.spinTimeout.value()
        
        self.logger.info(f"正在连接串口：{port} @ {baudrate}")
        self.serial_worker.connect(port, baudrate, timeout)
    
    def _disconnect(self):
        """断开串口连接"""
        self.logger.info("正在断开串口连接")
        self.serial_worker.stop_reading()
        self.serial_worker.disconnect()
    
    def _on_connection_changed(self, connected: bool):
        """连接状态改变"""
        self._is_connected = connected
        
        if connected:
            self.btnConnect.setText("关闭串口")
            self.btnConnect.setStyleSheet(
                "QPushButton { background-color: #e74c3c; color: white; "
                "font-weight: bold; padding: 8px; }"
            )
            self.labelConnectionStatus.setText("已连接")
            self.labelConnectionStatus.setStyleSheet("color: green; font-weight: bold;")
            self._enable_controls(True)
            port = self.comboPort.currentText()
            self.logger.info(f"串口已连接：{port}")
            self.serial_worker.start_reading()
        else:
            self.btnConnect.setText("打开串口")
            self.btnConnect.setStyleSheet(
                "QPushButton { font-weight: bold; padding: 8px; }"
            )
            self.labelConnectionStatus.setText("未连接")
            self.labelConnectionStatus.setStyleSheet("color: red; font-weight: bold;")
            self._enable_controls(False)
            self.logger.info("串口已断开")
    
    def _enable_controls(self, enabled: bool):
        """启用/禁用控件"""
        self.comboPort.setEnabled(not enabled)
        self.comboBaudrate.setEnabled(not enabled)
        self.spinTimeout.setEnabled(not enabled)
        self.btnRefresh.setEnabled(not enabled)
        self.btnSend.setEnabled(enabled)
        self.lineEditSend.setEnabled(enabled)
    
    def _on_error(self, error: str):
        """错误处理"""
        self.logger.error(error)
        QMessageBox.critical(self, "错误", error)
        # 发生错误时重置连接状态
        self._is_connected = False
        self.btnConnect.setText("打开串口")
        self.btnConnect.setStyleSheet("QPushButton { font-weight: bold; padding: 8px; }")
        self.labelConnectionStatus.setText("未连接")
        self.labelConnectionStatus.setStyleSheet("color: red; font-weight: bold;")
        self._enable_controls(False)
    
    # ============================================================
    # 数据收发方法
    # ============================================================
    def _send_data(self):
        """发送数据"""
        data_text = self.lineEditSend.text()
        if not data_text:
            self.logger.warning("发送数据为空")
            return
        
        if not self._is_connected:
            self.logger.error("串口未连接，无法发送数据")
            QMessageBox.warning(self, "警告", "请先打开串口")
            return
        
        hex_mode = self.checkHexSend.isChecked()
        
        try:
            if hex_mode:
                # HEX 模式发送 - 清理空格和逗号
                clean_hex = data_text.replace(' ', '').replace(',', '').upper()
                # 验证 HEX 格式
                if len(clean_hex) % 2 != 0:
                    self.logger.error(f"HEX 格式错误：长度为奇数")
                    QMessageBox.warning(self, "警告", "HEX 数据长度必须为偶数")
                    return
                if not all(c in '0123456789ABCDEF' for c in clean_hex):
                    self.logger.error(f"HEX 格式错误：包含非法字符")
                    QMessageBox.warning(self, "警告", "HEX 数据只能包含 0-9, A-F")
                    return
                data = bytes.fromhex(clean_hex)
            else:
                data = data_text.encode('utf-8')
            
            # 安全限制：检查数据大小
            if len(data) > MAX_SEND_BYTES:
                self.logger.error(f"发送数据过大：{len(data)} 字节 (最大 {MAX_SEND_BYTES})")
                QMessageBox.warning(
                    self, "警告",
                    f"发送数据过大:\n{len(data)} 字节\n最大允许：{MAX_SEND_BYTES} 字节"
                )
                return
            
            if self.serial_worker.send(data):
                self.bytes_sent += len(data)
                self._update_stats()
                self.logger.tx(data, hex_mode)
                
                # 显示到发送历史
                if hex_mode:
                    hex_str = ' '.join(f'{b:02X}' for b in data)
                    self.textSend.appendPlainText(f">>> {hex_str}")
                else:
                    self.textSend.appendPlainText(f">>> {data_text}")
                
                self.lineEditSend.clear()
            else:
                self.logger.error("发送失败：串口未连接")
        except ValueError as e:
            self.logger.error(f"HEX 转换错误：{str(e)}")
            QMessageBox.warning(self, "警告", f"HEX 格式错误:\n{str(e)}")
        except Exception as e:
            self.logger.error(f"发送数据错误：{str(e)}")
            QMessageBox.critical(self, "错误", f"发送失败:\n{str(e)}")
    
    def _on_data_received(self, data: bytes):
        """接收数据回调"""
        if data:
            self.bytes_received += len(data)
            self._update_stats()
            
            hex_mode = self.checkHexReceive.isChecked()
            self.logger.rx(data, hex_mode)
            
            # 显示到接收区
            if hex_mode:
                hex_str = ' '.join(f'{b:02X}' for b in data)
                self.textReceive.appendPlainText(f"<<< {hex_str}")
            else:
                try:
                    text = data.decode('utf-8', errors='replace')
                    self.textReceive.appendPlainText(f"<<< {text}")
                except:
                    self.textReceive.appendPlainText(f"<<< {data}")
    
    def _clear_receive(self):
        """清空接收区"""
        self.textReceive.clear()
        self.logger.info("接收区已清空")
    
    def _clear_send(self):
        """清空发送区"""
        self.textSend.clear()
        self.logger.info("发送区已清空")
    
    def _update_stats(self):
        """更新统计信息"""
        self.labelStats.setText(
            f"统计：发送 {self.bytes_sent} 字节 | 接收 {self.bytes_received} 字节"
        )
    
    # ============================================================
    # 窗口事件
    # ============================================================
    def closeEvent(self, event):
        """窗口关闭事件"""
        if self._is_connected:
            self.logger.info("正在关闭应用程序...")
            self._disconnect()
        self.logger.info("应用程序已关闭")
        event.accept()
    
    def keyPressEvent(self, event):
        """键盘事件 - Ctrl+Enter 也可以发送"""
        if event.key() == Qt.Key_Return and event.modifiers() == Qt.ControlModifier:
            self._send_data()
        else:
            super().keyPressEvent(event)


# ============================================================
# 主程序入口
# ============================================================
def main():


    """主函数"""
    app = QApplication(sys.argv)
    # app.setStyle("Fusion")
    
    window = SerialToolWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
